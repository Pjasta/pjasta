# kafka_producer_demo.py
from kafka import KafkaProducer
import json

producer = KafkaProducer(bootstrap_servers='kafka:9092', value_serializer=lambda v: json.dumps(v).encode('utf-8'))

sample = {
    'from_addr': 'attacker@example.com',
    'subject': 'URGENT: verify your account',
    'body': 'Dear user, please click https://evil-example.com/verify to update your password',
    'headers': {}
}

producer.send('emails', sample)
producer.flush()
