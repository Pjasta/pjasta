# feature_extractor.py
# Extracts URL, header and content features used by tabular and text models.

from urllib.parse import urlparse
import tldextract
import re

BRAND_LIST = ['google', 'gmail', 'paypal', 'facebook', 'amazon', 'microsoft']

def extract_urls_from_text(text):
    if not text:
        return []
    urls = re.findall(r'https?://[^\\s)>\'"]+', text)
    return urls

def url_features(url):
    parsed = urlparse(url)
    ext = tldextract.extract(url)
    host = parsed.hostname or ''
    path = parsed.path or ''
    query = parsed.query or ''

    features = {
        'url_len': len(url),
        'host_len': len(host),
        'path_len': len(path),
        'query_len': len(query),
        'subdomain_count': 0 if not ext.subdomain else len(ext.subdomain.split('.')),
        'tld': ext.suffix,
        'has_ip': bool(re.match(r'^\\d+\\.\\d+\\.\\d+\\.\\d+$', host)),
        'has_at': '@' in url,
        'punycode': 'xn--' in url,
        'num_digits': sum(c.isdigit() for c in url),
        'num_tokens': len(re.findall(r"[A-Za-z0-9_-]+", url)),
        'suspicious_brand_lev': max([levenshtein_ratio(host, b) for b in BRAND_LIST])
    }
    return features

# lightweight levenshtein ratio used for typo-squatting detection

def levenshtein_ratio(a, b):
    # simple ratio (1 - normalized distance); small strings only
    if not a or not b:
        return 0.0
    a = a.lower(); b = b.lower()
    # implement Wagner-Fischer
    m, n = len(a), len(b)
    dp = [[0]*(n+1) for _ in range(m+1)]
    for i in range(m+1):
        dp[i][0] = i
    for j in range(n+1):
        dp[0][j] = j
    for i in range(1, m+1):
        for j in range(1, n+1):
            cost = 0 if a[i-1]==b[j-1] else 1
            dp[i][j] = min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+cost)
    dist = dp[m][n]
    maxlen = max(m, n)
    return 1.0 - (dist / maxlen)

def extract_header_features(headers: dict):
    # Expecting headers from parsed email
    spf = headers.get('Received-SPF', '').lower()
    dkim = headers.get('DKIM-Signature', '')
    features = {
        'spf_pass': 1 if 'pass' in spf else 0,
        'dkim_present': 1 if dkim else 0,
        'from_replyto_mismatch': 1 if headers.get('From') != headers.get('Reply-To') else 0
    }
    return features

def content_features(text):
    # simple lexical features for social engineering
    urgent_tokens = ['urgent', 'immediately', 'verify', 'update', 'suspend', 'password']
    words = re.findall(r"\w+", text.lower() if text else '')
    num_words = len(words)
    token_counts = {t: words.count(t) for t in urgent_tokens}
    features = {
        'num_words': num_words,
        'num_exclamations': text.count('!') if text else 0,
        'num_urls': len(extract_urls_from_text(text)),
        **{f'has_{t}': 1 if token_counts[t]>0 else 0 for t in urgent_tokens}
    }
    return features
