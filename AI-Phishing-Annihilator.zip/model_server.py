# model_server.py
# Exposes endpoints to score incoming messages (URL features + text model)

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import joblib
import torch
from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification
from feature_extractor import url_features, extract_urls_from_text, content_features, extract_header_features

app = FastAPI(title='Phish-Annihilator Model Server')

# Load tabular model (LightGBM model saved with joblib)
TABULAR_PATH = 'models/tabular_model.joblib'
TEXT_MODEL_NAME = 'distilbert-base-uncased'

try:
    tabular = joblib.load(TABULAR_PATH)
except Exception as e:
    tabular = None

# Load text model
try:
    tokenizer = DistilBertTokenizerFast.from_pretrained(TEXT_MODEL_NAME)
    text_model = DistilBertForSequenceClassification.from_pretrained('./models/text_model')
    text_model.eval()
except Exception as e:
    tokenizer = None
    text_model = None

class IngestItem(BaseModel):
    from_addr: str
    subject: str = ''
    body: str = ''
    headers: dict = {}

@app.post('/score')
async def score_item(item: IngestItem):
    # 1. Header features
    header_feats = extract_header_features(item.headers)

    # 2. Content features
    cont_feats = content_features(item.body)

    # 3. URL features — take first URL for demo
    urls = extract_urls_from_text(item.body)
    url_feat = url_features(urls[0]) if urls else { 'url_len': 0, 'host_len': 0, 'path_len': 0, 'num_digits': 0 }

    # 4. Tabular predict
    tab_score = 0.0
    if tabular:
        feat_vector = {**header_feats, **cont_feats, **url_feat}
        # ensure order / columns
        X = [feat_vector.get(c, 0) for c in tabular['feature_names']]
        tab_score = tabular['model'].predict_proba([X])[0][1]

    # 5. Text predict
    text_score = 0.0
    if text_model and tokenizer:
        enc = tokenizer(item.body[:1000], truncation=True, padding='max_length', max_length=512, return_tensors='pt')
        with torch.no_grad():
            out = text_model(**enc)
            probs = torch.softmax(out.logits, dim=1).cpu().numpy()[0]
            text_score = float(probs[1])

    # 6. Ensemble
    final_score = 0.6*tab_score + 0.4*text_score
    decision = 'PHISHING' if final_score > 0.7 else 'SAFE'

    return {
        'tab_score': tab_score,
        'text_score': text_score,
        'final_score': final_score,
        'decision': decision,
        'explanation': explain_simple(header_feats, cont_feats, url_feat)
    }

def explain_simple(hdr, cont, urlf):
    reasons = []
    if hdr.get('spf_pass')==0:
        reasons.append('SPF not passing')
    if urlf.get('has_ip'):
        reasons.append('URL contains raw IP')
    if cont.get('has_urgent') if 'has_urgent' in cont else False:
        reasons.append('Urgency words present')
    return '; '.join(reasons) or 'No immediate red flags'
