# imap_fetcher.py
# Connects to IMAP, downloads new emails (for demo/testing only use your own account)

import imaplib
import email
from email import policy
import time

IMAP_HOST = 'imap.gmail.com'
IMAP_USER = 'your.test.email@gmail.com'
IMAP_PASS = 'app_password_or_token'
MAILBOX = 'INBOX'

def fetch_unseen_emails():
    mail = imaplib.IMAP4_SSL(IMAP_HOST)
    mail.login(IMAP_USER, IMAP_PASS)
    mail.select(MAILBOX)
    typ, data = mail.search(None, 'UNSEEN')
    for num in data[0].split():
        typ, msg_data = mail.fetch(num, '(RFC822)')
        raw = msg_data[0][1]
        msg = email.message_from_bytes(raw, policy=policy.default)
        yield msg
    mail.logout()

if __name__ == '__main__':
    while True:
        for msg in fetch_unseen_emails():
            print('From:', msg.get('from'))
            print('Subject:', msg.get('subject'))
            # here you would POST to your pipeline / Kafka
        time.sleep(30)
