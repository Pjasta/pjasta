# kafka_consumer_worker.py
from kafka import KafkaConsumer
import json
import requests

consumer = KafkaConsumer('emails', bootstrap_servers='kafka:9092', value_deserializer=lambda m: json.loads(m.decode('utf-8')))

MODEL_SERVER = 'http://model_server:8000/score'

for msg in consumer:
    item = msg.value
    resp = requests.post(MODEL_SERVER + '/score', json=item)
    print('Scored:', resp.json())
