AI Phishing Annihilator - Code bundle

1. Prepare data under /data (see trainer scripts)
2. Build docker images: docker-compose build
3. Start demo stack: docker-compose up
4. Train models outside docker or mount models folder
5. Use imap_fetcher.py to pull emails (demo) and forward to Kafka
