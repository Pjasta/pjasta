# trainer_tabular.py
# Train LightGBM on prepared CSV with feature columns + label

import pandas as pd
import joblib
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_recall_fscore_support

DATA = 'data/url_features_with_labels.csv'

if __name__ == '__main__':
    df = pd.read_csv(DATA)
    y = df['label']
    X = df.drop(columns=['label'])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    train_data = lgb.Dataset(X_train, label=y_train)
    params = {'objective': 'binary', 'metric': 'auc', 'verbosity': -1}
    model = lgb.train(params, train_data, num_boost_round=200)

    # evaluate
    preds = model.predict(X_test)
    auc = roc_auc_score(y_test, preds)
    print('AUC:', auc)

    # Save model and feature names
    wrapper = {'model': model, 'feature_names': list(X.columns)}
    joblib.dump(wrapper, 'models/tabular_model.joblib')
