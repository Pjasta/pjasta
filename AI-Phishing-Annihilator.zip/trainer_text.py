# trainer_text.py
# Fine-tune DistilBERT on labeled email bodies

from datasets import load_dataset, Dataset
from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification, Trainer, TrainingArguments
import pandas as pd

# Expect CSV with columns: text,label
CSV = 'data/email_text_labeled.csv'

if __name__ == '__main__':
    df = pd.read_csv(CSV)
    ds = Dataset.from_pandas(df)
    tokenizer = DistilBertTokenizerFast.from_pretrained('distilbert-base-uncased')

    def tokenize(batch):
        return tokenizer(batch['text'], truncation=True, padding='max_length', max_length=512)

    ds = ds.map(tokenize, batched=True)
    ds = ds.rename_column('label', 'labels')
    ds.set_format(type='torch', columns=['input_ids', 'attention_mask', 'labels'])

    model = DistilBertForSequenceClassification.from_pretrained('distilbert-base-uncased', num_labels=2)

    training_args = TrainingArguments(
        output_dir='./models/text_model',
        num_train_epochs=3,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        evaluation_strategy='epoch',
        save_strategy='epoch',
        logging_steps=50
    )

    trainer = Trainer(model=model, args=training_args, train_dataset=ds, eval_dataset=ds)
    trainer.train()
    trainer.save_model('./models/text_model')
